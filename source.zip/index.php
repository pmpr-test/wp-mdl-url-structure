<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68de671135a12             |
    |_______________________________________|
*/
 use Pmpr\Module\URLStructure\URLStructure; URLStructure::symcgieuakksimmu();
