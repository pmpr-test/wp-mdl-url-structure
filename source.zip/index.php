<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e580c6177e1             |
    |_______________________________________|
*/
 use Pmpr\Module\URLStructure\URLStructure; URLStructure::symcgieuakksimmu();
