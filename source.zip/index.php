<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705dc0272f9             |
    |_______________________________________|
*/
 use Pmpr\Module\URLStructure\URLStructure; URLStructure::symcgieuakksimmu();
