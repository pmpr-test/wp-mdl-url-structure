<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0b90e5d2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\URLStructure\Plugin\Plugin; use Pmpr\Module\URLStructure\Plugin\Woocommerce; use Pmpr\Module\URLStructure\Plugin\Yoast; class URLStructure extends ComponentInitiator { const uisisakqmumqggsg = "\x75\162\154\x5f\163\x74\162\165\x63\164\165\162\145\x5f"; public function register() { $this->gkieogwukagigisy(__DIR__, [Constants::qescuiwgsyuikume => static function () { return __("\x55\122\114\x20\123\x74\162\165\x63\x74\165\x72\x65", PR__MDL__URL_STRUCTURE); }, Constants::wuowaiyouwecckaw => false, Constants::sguyaymiiiiewame => Setting::class]); } public function mameiwsayuyquoeq() { Hook::symcgieuakksimmu(); Rewrite::symcgieuakksimmu(); Yoast::symcgieuakksimmu(); } }
