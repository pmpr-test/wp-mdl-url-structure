<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d0059041fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\URLStructure\Plugin\Plugin; use Pmpr\Module\URLStructure\Plugin\Woocommerce; use Pmpr\Module\URLStructure\Plugin\Yoast; class URLStructure extends ComponentInitiator { const uisisakqmumqggsg = "\165\x72\154\137\163\164\162\165\x63\164\x75\162\x65\137"; public function register() { $this->gkieogwukagigisy(__DIR__, [Constants::qescuiwgsyuikume => static function () { return __("\x55\x52\x4c\x20\x53\x74\x72\165\143\164\x75\162\x65", PR__MDL__URL_STRUCTURE); }, Constants::wuowaiyouwecckaw => false, Constants::sguyaymiiiiewame => Setting::class]); } public function mameiwsayuyquoeq() { Hook::symcgieuakksimmu(); Rewrite::symcgieuakksimmu(); Yoast::symcgieuakksimmu(); } }
