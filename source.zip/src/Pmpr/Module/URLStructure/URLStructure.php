<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8abc73ac             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\URLStructure\Plugin\Plugin; class URLStructure extends ComponentInitiator { const uisisakqmumqggsg = "\165\162\154\137\163\164\162\165\143\164\x75\x72\145\137"; public function register() { $this->gkieogwukagigisy(__DIR__, [Constants::qescuiwgsyuikume => static function () { return __("\125\122\114\x20\x53\164\x72\165\x63\164\x75\x72\145", PR__MDL__URL_STRUCTURE); }, Constants::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { Hook::symcgieuakksimmu(); Plugin::symcgieuakksimmu(); Rewrite::symcgieuakksimmu(); Setting::symcgieuakksimmu(); } }
