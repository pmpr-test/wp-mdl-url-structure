<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705dc0272f9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\URLStructure\Plugin\Plugin; use Pmpr\Module\URLStructure\Plugin\Woocommerce; use Pmpr\Module\URLStructure\Plugin\Yoast; class URLStructure extends ComponentInitiator { const uisisakqmumqggsg = "\x75\x72\x6c\137\163\164\x72\x75\x63\x74\x75\162\145\x5f"; public function register() { $this->gkieogwukagigisy(__DIR__, [Constants::qescuiwgsyuikume => static function () { return __("\125\x52\x4c\40\x53\x74\162\x75\143\x74\165\162\145", PR__MDL__URL_STRUCTURE); }, Constants::wuowaiyouwecckaw => false, Constants::sguyaymiiiiewame => Setting::class]); } public function mameiwsayuyquoeq() { Hook::symcgieuakksimmu(); Rewrite::symcgieuakksimmu(); Yoast::symcgieuakksimmu(); } }
