<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8abc73ac             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Plugin; class Woocommerce extends Common { }
