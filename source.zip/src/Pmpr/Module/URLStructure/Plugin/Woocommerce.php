<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7d7ec53e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Plugin; class Woocommerce extends Common { }
