<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7d7ec53e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Plugin; use Pmpr\Module\URLStructure\Container; class Plugin extends Container { public function mameiwsayuyquoeq() { Yoast::symcgieuakksimmu(); Woocommerce::symcgieuakksimmu(); } }
